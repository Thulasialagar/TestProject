# Employee Handler project which reads and delete the employee information from the XML file
Run the EmployeeXMLReaderOrWriter file which has the main method
To delete the employee provide the employee name
To add the employee please provide employee name, age, desgnation .
To add any node to the employee like adress provide those details as well.